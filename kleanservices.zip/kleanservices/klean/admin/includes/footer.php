<div class="copyrights">
	 <p>© <?php echo date('Y');?> Klean Services. All Rights Reserved |  <a href="#">Designed By BlueChips Solutions (Mokshada Yadav)</a> </p>
</div>	
