<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>@import url("https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700");</style>

<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
										
									 <li id="menu-academico" ><a href="#"><i class="material-icons">location_on</i><span>Washing Points</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="addcar-washpoint.php">Add</a></li>
											<li id="menu-academico-avaliacoes" ><a href="managecar-washingpoints.php">Manage</a></li>
										  </ul>
										</li>

	<li><a href="add-booking.php"><i class="fa fa-files-o" aria-hidden="true"></i>  <span>Add Car Wash Booking</span><div class="clearfix"></div></a></li>


		 <li id="menu-academico" ><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span>Car Washing Booking</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="new-booking.php">New</a></li>
											<li id="menu-academico-avaliacoes" ><a href="completed-booking.php">Completed</a></li>
												<li id="menu-academico-avaliacoes" ><a href="all-bookings.php">All</a></li>
										  </ul>
										</li>
									
								
						
									<li><a href="manage-enquires.php"><i class="material-icons">question_answer</i>  <span>Manage Inquiries</span><div class="clearfix"></div></a></li>
		 <li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Pages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="about.php">About</a></li>
											<li id="menu-academico-avaliacoes" ><a href="contact.php">Contact</a></li>
											
										  </ul>
										</li>
										<li><a href="services.php"><i class="material-icons">local_car_wash</i>  <span>Services</span><div class="clearfix"></div></a></li>					     
									
								  </ul>
								</div>
							  </div>